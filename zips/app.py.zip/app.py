from flask import Flask, render_template, request, jsonify, send_file
import os
import zipfile
import io

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/list_items', methods=['POST'])
def list_items():
    directory = request.form['directory']
    try:
        items = os.listdir(directory)
        return jsonify(items)
    except Exception as e:
        return jsonify({"error": str(e)})

@app.route('/zip_items', methods=['POST'])
def zip_items():
    directory = request.form['directory']
    selected_items = request.form.getlist('items')
    print(f"Selected items: {selected_items}")
    
    zip_folder = os.path.join(directory, 'zips')
    os.makedirs(zip_folder, exist_ok=True)
    
    zipped_files = []
    for item in selected_items:
        item_path = os.path.join(directory, item)
        zip_path = os.path.join(zip_folder, f"{item}.zip")
        with zipfile.ZipFile(zip_path, 'w') as zip_file:
            if os.path.isfile(item_path):
                zip_file.write(item_path, arcname=item)
            elif os.path.isdir(item_path):
                for root, _, files in os.walk(item_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        zip_file.write(file_path, arcname=os.path.relpath(file_path, directory))
        zipped_files.append(zip_path)
    
    return jsonify({"zipped_files": zipped_files})

@app.route('/download_zip', methods=['GET'])
def download_zip():
    zip_path = request.args.get('zip_path')
    if zip_path and os.path.exists(zip_path):
        return send_file(zip_path, mimetype='application/zip', as_attachment=True, download_name=os.path.basename(zip_path))
    else:
        return jsonify({"error": "File not found."})

if __name__ == '__main__':
    app.run(debug=True)
